document.addEventListener('DOMContentLoaded', function () {

    // =====================================================
    //  HERO BACKGROUND CAROUSEL (Bootstrap-based)
    // =====================================================
    const heroCarousel = document.querySelector('#heroCarousel');
    if (heroCarousel && window.bootstrap && typeof bootstrap.Carousel === 'function') {
        new bootstrap.Carousel(heroCarousel, {
            interval: 5000,
            ride: 'carousel'
        });
    }

    // =====================================================
    //  GALLERY CAROUSEL (If exists on page)
    // =====================================================
    const galleryEl = document.querySelector('#galleryCarousel');
    if (galleryEl && window.bootstrap && typeof bootstrap.Carousel === 'function') {
        const bsCarousel = new bootstrap.Carousel(galleryEl, { interval: 3000 });

        // Optional: pause on hover
        galleryEl.addEventListener('mouseenter', () => bsCarousel.pause());
        galleryEl.addEventListener('mouseleave', () => bsCarousel.cycle());
    }

    // =====================================================
    //  FADE-IN ANIMATION ON SCROLL
    // =====================================================
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    const observerOptions = {
        root: null,
        rootMargin: '0px 0px -100px 0px',
        threshold: 0.15
    };

    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                obs.unobserve(entry.target);
            }
        });
    }, observerOptions);

    animatedElements.forEach(el => observer.observe(el));

    // =====================================================
    //  NEWS CAROUSEL (4 per page + auto sort by date)
    // =====================================================
    function setupNewsBoard() {
        const newsCarousel = document.querySelector('.news-carousel');
        const newsItems = Array.from(document.querySelectorAll('.news-carousel .news-item'));
        const slickDots = document.querySelector('.slick-dots');
        if (!newsCarousel || !newsItems.length || !slickDots) return;

        // --- 1) SORT BY DATE (Latest first) ---
        newsItems.sort((a, b) => {
            const getDate = (item) => {
                const dateEl = item.querySelector('.news-date');
                if (!dateEl) return new Date(0);

                const [day, month, year] = dateEl.innerHTML.trim().split('<br>');
                return new Date(`${month} ${day}, ${year}`);
            };
            return getDate(b) - getDate(a);
        });

        // Re-append sorted items
        newsItems.forEach(item => newsCarousel.appendChild(item));

        // --- 2) FIXED: ALWAYS SHOW 4 PER PAGE ---
        let visibleCount = 4;
        let newsIndex = 0;

        function showNews(index) {
            const total = newsItems.length;
            const totalPages = Math.ceil(total / visibleCount);

            const page = Math.min(Math.floor(index / visibleCount), totalPages - 1);
            const start = page * visibleCount;
            const end = start + visibleCount;

            newsItems.forEach((item, i) => {
                item.style.display = (i >= start && i < end) ? 'block' : 'none';
                item.classList.toggle('news-fade-in', i >= start && i < end);
            });

            Array.from(slickDots.children).forEach((li, i) =>
                li.classList.toggle('slick-active', i === page)
            );

            newsIndex = start;
        }

        function createDots() {
            slickDots.innerHTML = '';
            const dotCount = Math.ceil(newsItems.length / visibleCount);

            for (let i = 0; i < dotCount; i++) {
                const li = document.createElement('li');
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.innerHTML = '<span></span>';
                btn.addEventListener('click', () => showNews(i * visibleCount));
                li.appendChild(btn);
                slickDots.appendChild(li);
            }
        }

        createDots();
        showNews(0);
    }
    // Initialize News Board
    if (document.querySelector('.news-carousel') && document.querySelector('.slick-dots')) {
        setupNewsBoard();
    } else {
        const observer = new MutationObserver(() => {
            if (document.querySelector('.news-carousel') && document.querySelector('.slick-dots')) {
                observer.disconnect();
                setupNewsBoard();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

});
